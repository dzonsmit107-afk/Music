package dev.lune.player

import android.Manifest
import android.content.ComponentName
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.delay
import java.util.concurrent.ExecutionException

class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var mediaController by mutableStateOf<MediaController?>(null)
    private var permissionGranted by mutableStateOf(false)

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        permissionGranted = hasAudioPermission()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        permissionGranted = hasAudioPermission()
        if (!permissionGranted) requestAudioPermission()
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            permissionLauncher.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
        }

        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try {
                mediaController = controllerFuture?.get()
            } catch (_: ExecutionException) {
                mediaController = null
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
            }
        }, ContextCompat.getMainExecutor(this))

        setContent {
            var darkMode by remember {
                mutableStateOf(getPreferences(MODE_PRIVATE).getBoolean("dark_mode", true))
            }
            LuneTheme(dark = darkMode) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    val controller = mediaController
                    if (!permissionGranted) {
                        PermissionScreen { requestAudioPermission() }
                    } else {
                        LuneApp(
                            controller = controller,
                            darkMode = darkMode,
                            onDarkModeChange = {
                                darkMode = it
                                getPreferences(MODE_PRIVATE).edit().putBoolean("dark_mode", it).apply()
                            },
                            tracks = remember(permissionGranted) { AudioRepository.load(this) }
                        )
                    }
                }
            }
        }
    }

    private fun hasAudioPermission(): Boolean {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE
        return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestAudioPermission() {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE
        permissionLauncher.launch(arrayOf(permission))
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        mediaController = null
        super.onDestroy()
    }
}

@Composable
private fun PermissionScreen(onRequest: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.LibraryMusic, null, modifier = Modifier.size(56.dp))
        Spacer(Modifier.height(16.dp))
        Text("Доступ к музыке", style = MaterialTheme.typography.headlineSmall)
        Text("Разрешение нужно только для поиска локальных аудиофайлов.", modifier = Modifier.padding(vertical = 12.dp))
        Button(onClick = onRequest) { Text("Разрешить доступ") }
    }
}

@Composable
private fun LuneApp(
    controller: MediaController?,
    darkMode: Boolean,
    onDarkModeChange: (Boolean) -> Unit,
    tracks: List<AudioTrack>
) {
    var tab by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    var selectedFolder by remember { mutableStateOf("Все папки") }
    var currentIndex by remember { mutableIntStateOf(controller?.currentMediaItemIndex ?: -1) }
    var isPlaying by remember { mutableStateOf(controller?.isPlaying == true) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var showQueue by remember { mutableStateOf(false) }

    LaunchedEffect(controller) {
        while (true) {
            if (controller != null) {
                currentIndex = controller.currentMediaItemIndex
                isPlaying = controller.isPlaying
                position = controller.currentPosition.coerceAtLeast(0L)
                duration = controller.duration.takeIf { it > 0 } ?: 0L
            }
            delay(500)
        }
    }

    val folders = remember(tracks) { listOf("Все папки") + tracks.map { it.folder }.distinct().sorted() }
    val filtered = remember(tracks, query, selectedFolder) {
        tracks.filter {
            (selectedFolder == "Все папки" || it.folder == selectedFolder) &&
                (query.isBlank() || it.title.contains(query, true) || it.artist.contains(query, true) || it.album.contains(query, true))
        }
    }
    val currentTrack = controller?.currentMediaItem?.let { item ->
        tracks.find { it.id.toString() == item.mediaId }
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0,
                    onClick = { tab = 0 },
                    icon = { Icon(Icons.Default.MusicNote, contentDescription = null) },
                    label = { Text("Музыка") }
                )
                NavigationBarItem(
                    selected = tab == 1,
                    onClick = { tab = 1 },
                    icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                    label = { Text("Настройки") }
                )
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            if (tab == 0) {
                Column(Modifier.fillMaxSize()) {
                    Text("Lune", style = MaterialTheme.typography.headlineLarge, modifier = Modifier.padding(start = 20.dp, top = 18.dp, bottom = 12.dp))
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                        singleLine = true,
                        placeholder = { Text("Поиск музыки") },
                        leadingIcon = { Icon(Icons.Default.Search, null) },
                        trailingIcon = {
                            if (query.isNotEmpty()) IconButton(onClick = { query = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "Очистить поиск")
                            }
                        },
                        shape = RoundedCornerShape(28.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                    var folderMenu by remember { mutableStateOf(false) }
                    Box(Modifier.padding(horizontal = 16.dp)) {
                        OutlinedButton(onClick = { folderMenu = true }) {
                            Icon(Icons.Default.Folder, null)
                            Spacer(Modifier.width(8.dp))
                            Text(selectedFolder, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Icon(Icons.Default.ArrowDropDown, null)
                        }
                        DropdownMenu(expanded = folderMenu, onDismissRequest = { folderMenu = false }) {
                            folders.forEach { folder ->
                                DropdownMenuItem(
                                    text = { Text(folder) },
                                    onClick = { selectedFolder = folder; folderMenu = false }
                                )
                            }
                        }
                    }
                    if (tracks.isEmpty()) {
                        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Text("Музыка не найдена", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    } else {
                        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 8.dp)) {
                            items(filtered, key = { it.id }) { track ->
                                TrackRow(track = track, onClick = {
                                    val queue = filtered.ifEmpty { tracks }
                                    controller?.setMediaItems(queue.map { it.toMediaItem() }, queue.indexOf(track), 0L)
                                    controller?.prepare()
                                    controller?.play()
                                })
                            }
                        }
                    }
                    if (currentTrack != null) {
                        MiniPlayer(
                            track = currentTrack,
                            playing = isPlaying,
                            onPlayPause = { if (isPlaying) controller?.pause() else controller?.play() },
                            onNext = { controller?.seekToNextMediaItem() },
                            onOpenQueue = { showQueue = true }
                        )
                    }
                }
            } else {
                SettingsScreen(darkMode, onDarkModeChange, tracks.size)
            }
        }
    }

    if (showQueue && controller != null) {
        AlertDialog(
            onDismissRequest = { showQueue = false },
            title = { Text("Очередь") },
            text = {
                val queueItems = (0 until controller.mediaItemCount).mapNotNull { i ->
                    controller.getMediaItemAt(i).let { item ->
                        tracks.find { it.id.toString() == item.mediaId }?.let { i to it }
                    }
                }
                if (queueItems.isEmpty()) Text("Очередь пуста")
                else LazyColumn(Modifier.heightIn(max = 400.dp)) {
                    items(queueItems, key = { it.first }) { (index, track) ->
                        ListItem(
                            headlineContent = { Text(track.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            supportingContent = { Text(track.artist, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            leadingContent = { Icon(Icons.Default.MusicNote, null) },
                            modifier = Modifier.clickable {
                                controller.seekToDefaultPosition(index)
                                controller.play()
                                showQueue = false
                            }
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showQueue = false }) { Text("Закрыть") } }
        )
    }
}

@Composable
private fun TrackRow(track: AudioTrack, onClick: () -> Unit) {
    ListItem(
        headlineContent = { Text(track.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        supportingContent = { Text(track.artist, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        leadingContent = {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.size(48.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.MusicNote, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        },
        trailingContent = { Text(formatDuration(track.durationMs), style = MaterialTheme.typography.labelMedium) },
        modifier = Modifier.clickable(onClick = onClick)
    )
}

@Composable
private fun MiniPlayer(
    track: AudioTrack,
    playing: Boolean,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onOpenQueue: () -> Unit
) {
    Surface(
        tonalElevation = 3.dp,
        color = MaterialTheme.colorScheme.surfaceContainer,
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(start = 14.dp, end = 6.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Album, null, modifier = Modifier.size(36.dp), tint = MaterialTheme.colorScheme.primary)
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(track.title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleSmall)
                Text(track.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = onPlayPause) {
                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, if (playing) "Пауза" else "Воспроизвести")
            }
            IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, "Следующий трек") }
            IconButton(onClick = onOpenQueue) { Icon(Icons.Default.QueueMusic, "Очередь") }
        }
    }
}

@Composable
private fun SettingsScreen(darkMode: Boolean, onDarkModeChange: (Boolean) -> Unit, trackCount: Int) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Настройки", style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(20.dp))
        ListItem(
            headlineContent = { Text("Тёмная тема") },
            supportingContent = { Text("Фиксированная палитра в стиле Android 12") },
            leadingContent = { Icon(Icons.Default.DarkMode, null) },
            trailingContent = { Switch(checked = darkMode, onCheckedChange = onDarkModeChange) }
        )
        HorizontalDivider()
        ListItem(
            headlineContent = { Text("Локальная библиотека") },
            supportingContent = { Text("$trackCount аудиофайлов") },
            leadingContent = { Icon(Icons.Default.LibraryMusic, null) }
        )
        HorizontalDivider()
        ListItem(
            headlineContent = { Text("О приложении") },
            supportingContent = { Text("Lune Player 1.0 · без интернета, рекламы и аккаунтов") },
            leadingContent = { Icon(Icons.Default.Info, null) }
        )
    }
}

private fun formatDuration(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(totalSeconds / 60, totalSeconds % 60)
}
