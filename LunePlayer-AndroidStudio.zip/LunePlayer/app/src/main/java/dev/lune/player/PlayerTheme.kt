package dev.lune.player

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NightScheme = darkColorScheme(
    primary = Color(0xFFB8C7FF),
    onPrimary = Color(0xFF142B60),
    primaryContainer = Color(0xFF2B4178),
    onPrimaryContainer = Color(0xFFDCE1FF),
    secondary = Color(0xFFC2C6DD),
    background = Color(0xFF111318),
    surface = Color(0xFF111318),
    surfaceVariant = Color(0xFF444750),
    onSurface = Color(0xFFE2E2E9),
    onSurfaceVariant = Color(0xFFC4C6D0)
)

private val DayScheme = lightColorScheme(
    primary = Color(0xFF405A9C),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFDCE1FF),
    onPrimaryContainer = Color(0xFF001849),
    secondary = Color(0xFF585E71),
    background = Color(0xFFF9F9FF),
    surface = Color(0xFFF9F9FF),
    surfaceVariant = Color(0xFFE2E2EC),
    onSurface = Color(0xFF191B22),
    onSurfaceVariant = Color(0xFF444750)
)

@Composable
fun LuneTheme(dark: Boolean? = null, content: @Composable () -> Unit) {
    val useDark = dark ?: isSystemInDarkTheme()
    MaterialTheme(
        colorScheme = if (useDark) NightScheme else DayScheme,
        content = content
    )
}
